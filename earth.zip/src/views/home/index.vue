<template>
  <div>
    Home
  </div>
</template>
<script>
import Input from "@/components/Input";
export default {
  components: {
    Input,
  },
  data() {
    return {
    };
  },
  mounted() {
  },
};
</script>
